from electrum.i18n import _

fullname = _('Email')
description = _("Send and receive payment request with an email account")
available_for = ['qt']
